local shared = require("shared-pre")
shared.max_catch_radius = settings.startup["af-tls-rod-catch-radius"].value
shared.min_catch_radius = 8
return shared